#  Copyright (C) 2020 Matteo Benedetto <me at enne2.net>
# ©2021 Creative Sensor Inc. All rights reserved.
# This sample is to demonstrate how to access CSI Saturn device.
# Unless authorized by Creative Sensors Inc., you're not allowed
# to distribute or disclose any piece of codes in this sample,
# or to claim the copyright of this sample.

# ----- Saturn device commands list start -----
SATURN_IP = 'http://192.168.2.8'
CMD_STREAMING_URL = SATURN_IP+':8221'
CMD_MODE_SETUP = SATURN_IP+'/SetMode?Setup'
CMD_MODE_PHOTO_CAP = SATURN_IP+'/SetMode?PhotoCapture'
CMD_READ_CONFIG = SATURN_IP+'/Misc?ReadConfig'
CMD_ACK = SATURN_IP+'/Misc?AliveAck'
CMD_CAMERA_RESOLUTION_320X240 = SATURN_IP+'/Setup?Resolution=0'
CMD_CAMERA_RESOLUTION_640X480 = SATURN_IP+'/Setup?Resolution=1'
CMD_CAMERA_RESOLUTION_960X720 = SATURN_IP+'/Setup?Resolution=2'
CMD_CAMERA_QUALITY_GOOD = SATURN_IP+'/Setup?Quality=0'
CMD_CAMERA_QUALITY_NORMAL = SATURN_IP+'/Setup?Quality=1'
CMD_CAMERA_QUALITY_LOW = SATURN_IP+'/Setup?Quality=2'
# ----- Saturn device commands list end -----
import cv2 as cv
import numpy as np
import struct, collections, math, json, pickle
import urllib.request, requests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from multiprocessing import Manager, Pool, pool
import gi
gi.require_version('Gst', '1.0')
gi.require_version('GstRtspServer', '1.0')
from gi.repository import Gst, GLib, GObject, GstRtspServer

frame_result=np.zeros([960,720])
CSI_ready=False

class CSI_Saturn():        
    def FrameDecode(self,RGB_queue, IR_queue, TA_queue, GO_queue):
        EEPROM = collections.OrderedDict({})
        VDD = []
        PTAT = []
        BLIND_DATA = []
        stream_buffer = b''
        # Please modified it if you have wifi quality issues
        PACKET_SIZE = 1024

        print('Start streaming...')
        stream = urllib.request.urlopen(CMD_STREAMING_URL)
        while True:
            # Parse SOI
            start = stream_buffer.find(b'\xff\xd8')
            while (start == -1):
                stream_buffer += stream.read(PACKET_SIZE)
                start = stream_buffer.find(b'\xff\xd8')
            stream_buffer = stream_buffer[start:]
            start = 2

            # Parse APP0
            while (len(stream_buffer[start:]) < 4):  # 4 bytes for header
                stream_buffer += stream.read(PACKET_SIZE)
            pos = stream_buffer[start:].find(b'\xff\xe0')
            if (pos == -1):
                # Parse APP0 marker fail ! Find next SOI ...
                continue

            start = start + pos
            header = stream_buffer[start:start + 4]
            marker = header[0:2]  # 2 bytes
            size = struct.unpack('>H', header[2:4])[0]  # 2 bytes
            while (len(stream_buffer[start + 2:]) < size):
                stream_buffer += stream.read(PACKET_SIZE)
            start = start + 2 + size

            # Parse APP15
            while (True):
                while (len(stream_buffer[start:]) < 10):  # 10 bytes for header
                    stream_buffer += stream.read(PACKET_SIZE)
                pos = stream_buffer[start:].find(b'\xff\xef')
                if (pos == -1):
                    # No more APP15 markers...
                    break
                else:
                    start = start + pos
                    header = stream_buffer[start:start + 10]
                    marker = header[0:2]  # 2 bytes
                    size = struct.unpack('>H', header[2:4])[0]
                    type = header[4:9]  # 5 bytes
                    rev = header[9:10]  # 1 byte
                    while (len(stream_buffer[start + 2:]) < size):
                        stream_buffer += stream.read(PACKET_SIZE)

                    if (type == b'TRAW\x00'):
                        content = stream_buffer[start + 10:start + 2 + size]
                        frame_counter = struct.unpack('>I', content[0:4])[0]
                        use_vdd = struct.unpack('?', content[4:5])[0]  # 1 bytes, bool, 0: PTAT value, 1: Vdd voltage
                        reserved = content[5:6]  # 1 bytes, should be 0xFF
                        if (use_vdd):
                            VDD = [struct.unpack('>H', content[6 + n:6 + n + 2])[0] for n in
                                range(0, 8 * 2, 2)]  # 8 values, 16-bit unsigned
                        else:
                            PTAT = [struct.unpack('>H', content[6 + n:6 + n + 2])[0] for n in
                                    range(0, 8 * 2, 2)]  # 8 values, 16-bit unsigned

                        # Thermal Raw Data 80x64 16-bit unsigned, size: 10240 bytes
                        raw_data = struct.unpack('>5120H', content[6 + 8 * 2: 6 + 8 * 2 + 10240])
                        raw_data = np.asarray(raw_data).astype(np.float64)

                        if (len(EEPROM.keys()) > 0):
                            if (len(PTAT) > 0):
                                # Ambient Temperature
                                PTAT_avg = float(np.mean(PTAT))
                                Ta = PTAT_avg * EEPROM['PTAT_gradient'] + EEPROM['PTAT_offset']
                                while (TA_queue.qsize() > 1): TA_queue.get()
                                TA_queue.put(Ta)

                                # Thermal Offset Compensation
                                raw_data = raw_data - (np.asarray(EEPROM['ThGrad']) * PTAT_avg) / math.pow(2, EEPROM[
                                    'gradScale']) - np.asarray(EEPROM['ThOffset'])

                                # Electrical Offset Compensation
                                if (len(BLIND_DATA) > 0):
                                    TOP_BLIND = np.asarray(BLIND_DATA)[:640]
                                    TOP_BLIND = np.tile(TOP_BLIND, (4,))
                                    BOT_BLIND = np.asarray(BLIND_DATA)[640:]
                                    BOT_BLIND = np.tile(BOT_BLIND, (4,))
                                    FULL_BLIND = np.concatenate([TOP_BLIND, BOT_BLIND], axis=-1)
                                    raw_data = raw_data - FULL_BLIND

                                    # Vdd Compensation
                                    if (len(VDD) > 0):
                                        VDD_avg = float(np.mean(VDD))

                                        TOP_VddCompGrad = np.asarray(EEPROM['VddCompGrad'])[:640]
                                        TOP_VddCompGrad = np.tile(TOP_VddCompGrad, (4,))
                                        BOT_VddCompGrad = np.asarray(EEPROM['VddCompGrad'])[640:]
                                        BOT_VddCompGrad = np.tile(BOT_VddCompGrad, (4,))
                                        FULL_VddCompGrad = np.concatenate([TOP_VddCompGrad, BOT_VddCompGrad], axis=-1)

                                        TOP_VddCompOff = np.asarray(EEPROM['VddCompOff'])[:640]
                                        TOP_VddCompOff = np.tile(TOP_VddCompOff, (4,))
                                        BOT_VddCompOff = np.asarray(EEPROM['VddCompOff'])[640:]
                                        BOT_VddCompOff = np.tile(BOT_VddCompOff, (4,))
                                        FULL_VddCompOff = np.concatenate([TOP_VddCompOff, BOT_VddCompOff], axis=-1)

                                        A = (FULL_VddCompGrad * PTAT_avg / math.pow(2, EEPROM['VddScGrad']) + FULL_VddCompOff) / math.pow(2,
                                                                                                                                            EEPROM[
                                                                                                                                            'VddScOff'])
                                        B = (VDD_avg - EEPROM['VDD_TH1'] - (EEPROM['VDD_TH2'] - EEPROM['VDD_TH1']) * (
                                                    PTAT_avg - EEPROM['PTAT_TH1']) / (EEPROM['PTAT_TH2'] - EEPROM['PTAT_TH1']))
                                        raw_data = raw_data - A * B

                                        # Sensitivity Compensation
                                        PCSCALEVAL = 1 * pow(10, 8)
                                        for i in range(len(raw_data)):
                                            PixC = (EEPROM['P'][i] * (EEPROM['PixCmax'] - EEPROM['PixCmin']) / 65535.0 + EEPROM['PixCmin']) * (
                                                    EEPROM['epsilon'] / 100.0) * (EEPROM['GlobalGain'] / 10000.0);
                                            raw_data[i] = (raw_data[i] * PCSCALEVAL) / PixC

                                        while (GO_queue.qsize() > 1): GO_queue.get()
                                        GO_queue.put(EEPROM['GlobalOff'])

                        # sensor output WxH: 80x64
                        raw_data = raw_data.reshape((64, 80))
                        # sensor raw data is up-side down
                        raw_data = np.flipud(raw_data)
                        frame_IR = raw_data

                        while (IR_queue.qsize() > 1): IR_queue.get()
                        IR_queue.put(frame_IR)

                    elif (type == b'TBLD\x00'):
                        content = stream_buffer[start + 10:start + 2 + size]
                        TOP_BLD = struct.unpack('>H', content[0:2])[0]
                        BOT_BLD = struct.unpack('>H', content[2:4])[0]
                        reserved = content[4:6]  # 2 bytes, should be 0xFF
                        BLIND_DATA = struct.unpack('>1280H', content[6:])
                    elif (type == b'TCAL\x00'):
                        content = stream_buffer[start + 10:start + 2 + size]
                        MBIT_TRIM = struct.unpack('b', content[0:1])[0]
                        BIAS_TRIM = struct.unpack('b', content[1:2])[0]
                        BPA_TRIM = struct.unpack('b', content[2:3])[0]
                        PU_SCL_TRIM = struct.unpack('b', content[3:4])[0]
                        CLK_TRIM = struct.unpack('b', content[4:5])[0]
                        reserved = content[5:6]  # 1 bytes, should be 0xFF
                        eeprom = content[6:]
                        if (len(eeprom) != 32768):
                            print('[ERROR] EEPROM size is not 32768 ! (%d)' % (len(EEPROM)))
                            input()

                        EEPROM['PixCmin'] = struct.unpack('<f', eeprom[0x00:0x04])[0]  # 4 bytes little endian
                        EEPROM['PixCmax'] = struct.unpack('<f', eeprom[0x04:0x08])[0]  # 4 bytes little endian
                        EEPROM['gradScale'] = struct.unpack('B', eeprom[0x08:0x09])[0]  # 1 byte
                        EEPROM['TN'] = struct.unpack('<H', eeprom[0x0b:0x0d])[0]  # 2 byte
                        EEPROM['epsilon'] = struct.unpack('B', eeprom[0x0d:0x0e])[0]  # 1 byte

                        EEPROM['MBIT_calib'] = struct.unpack('B', eeprom[0x001a:0x001b])[0]  # 1 byte
                        EEPROM['BIAS_calib'] = struct.unpack('B', eeprom[0x001b:0x001c])[0]  # 1 byte
                        EEPROM['CLK_calib'] = struct.unpack('B', eeprom[0x001c:0x001d])[0]  # 1 byte
                        EEPROM['BPA_calib'] = struct.unpack('B', eeprom[0x001d:0x001e])[0]  # 1 byte
                        EEPROM['PU_calib'] = struct.unpack('B', eeprom[0x001e:0x001f])[0]  # 1 byte

                        EEPROM['VDD_TH1'] = struct.unpack('<H', eeprom[0x0026:0x0028])[0]  # 2 byte
                        EEPROM['VDD_TH2'] = struct.unpack('<H', eeprom[0x0028:0x002a])[0]  # 2 byte
                        EEPROM['PTAT_gradient'] = struct.unpack('<f', eeprom[0x0034:0x0038])[0]  # 4 byte
                        EEPROM['PTAT_offset'] = struct.unpack('<f', eeprom[0x0038:0x003c])[0]  # 4 byte
                        EEPROM['PTAT_TH1'] = struct.unpack('<H', eeprom[0x003c:0x003e])[0]  # 2 byte
                        EEPROM['PTAT_TH2'] = struct.unpack('<H', eeprom[0x003e:0x0040])[0]  # 2 byte
                        EEPROM['VddScGrad'] = struct.unpack('B', eeprom[0x004e:0x004f])[0]  # 1 byte
                        EEPROM['VddScOff'] = struct.unpack('B', eeprom[0x004f:0x0050])[0]  # 1 byte

                        EEPROM['GlobalOff'] = struct.unpack('b', eeprom[0x0054:0x0055])[0]  # GlobalOff is stored as an 8 bit signed value,
                        EEPROM['GlobalGain'] = struct.unpack('<H', eeprom[0x0055:0x0057])[0]  # 2 byte, 16 bit unsigned values
                        EEPROM['VddCalib'] = struct.unpack('<H', eeprom[0x0057:0x0059])[0]  # 2 byte, 16 bit unsigned values
                        EEPROM['NrOfDefPix'] = struct.unpack('B', eeprom[0x007f:0x0080])[0]  # 1 byte, 8 bit unsigned values

                        EEPROM['VddCompGrad'] = struct.unpack('<1280h', eeprom[0x0800:0x1200])  # 2560 bytes, 16 bit signed values
                        EEPROM['VddCompOff'] = struct.unpack('<1280h', eeprom[0x1200:0x1c00])  # 2560 bytes, 16 bit signed values

                        EEPROM['ThGrad'] = struct.unpack('<5120b', eeprom[0x1c00:0x3000])  # 5120 bytes, 8 bit signed values
                        EEPROM['ThOffset'] = struct.unpack('<5120h', eeprom[0x3000:0x5800])  # 10240 bytes, 16 bit signed values
                        EEPROM['P'] = struct.unpack('<5120H', eeprom[0x5800:0x8000])  # 10240 bytes, 16 bit unsigned values

                    start = start + 2 + size

            # Parse EOI
            end = stream_buffer[start:].find(b'\xff\xd9')
            while (end == -1):
                stream_buffer += stream.read(PACKET_SIZE)
                end = stream_buffer[start:].find(b'\xff\xd9')  # JPEG end
            end = start + end

            # Decode one image
            jpg_buf = stream_buffer[:end + 2]  # actual image
            try:
                frame_RGB = cv.imdecode(np.frombuffer(jpg_buf, dtype=np.uint8), cv.IMREAD_COLOR)
                if (frame_RGB is not None):
                    while (RGB_queue.qsize() > 1): RGB_queue.get()
                    RGB_queue.put(frame_RGB)
            except Exception as e:
                print('[ERROR] decode one frame error:', e)
            stream_buffer = stream_buffer[end + 2:]
    def Execute(self):
        global frame_result
        global CSI_ready
        # load temperature lookup table
        with open('xtatemp.pkl', 'rb') as f: XTATemp = pickle.load(f)
        with open('yadvalues.pkl', 'rb') as f: YADValues = pickle.load(f)
        with open('temptable.pkl', 'rb') as f: temp_table = pickle.load(f)

        # [Connection Sequence]
        # 1. Reset device
        # CMD_MODE_SETUP must send to device before a new streaming
        requests.get(CMD_MODE_SETUP)

        # 2. Change RGB resolution
        # resolution takes effect only before streaming
        requests.get(CMD_CAMERA_RESOLUTION_960X720)

        # 3. Change RGB quality (MJPG compression)
        # quality takes effect only before streaming
        requests.get(CMD_CAMERA_QUALITY_GOOD)

        # 4. (optional) CMD_ACK must send to device periodically if streaming stopped
        # this is to keep connection alive in device side
        requests.get(CMD_ACK)

        # 5. CMD_MODE_PHOTO_CAP must send to device before a new streaming
        requests.get(CMD_MODE_PHOTO_CAP)

        # 6. CMD_READ_CONFIG is to fetch configurations from device
        # should be used only once and before streaming
        r = requests.get(CMD_READ_CONFIG)
        jsonString = '{' + r.text.split('{')[1].split('}')[0] + '}'
        configDict = json.loads(jsonString)
        FPN = np.asarray(configDict['fpn']).reshape((64, 80))
        REC = float(configDict['recalibration'])
        OFFSET = float(configDict['temperatureOffset'])

        # multi-processing resources
        MP_Pool = Pool(1)
        MP_Manager = Manager()
        RGB_queue = MP_Manager.Queue()
        IR_queue = MP_Manager.Queue()
        TA_queue = MP_Manager.Queue()
        GO_queue = MP_Manager.Queue()

        # Fork a process to receive stream and decode frame
        # put results into queues for parent process to access
        MP_Pool.starmap_async(self.FrameDecode, [(RGB_queue, IR_queue, TA_queue, GO_queue)])

        frame_RGB = frame_IR = None
        TA = GO = None
        TNR_LIST = []
        FACE_EMISSIVITY = 0.98       
        while(True):
            if (cv.waitKey(1) == 27):
                # if user hit esc
                MP_Pool.terminate()
                break
            if (TA_queue.qsize() > 0):
                TA = TA_queue.get()
            if (GO_queue.qsize() > 0):
                GO = GO_queue.get()
            if (RGB_queue.qsize() > 0):
                frame_RGB = RGB_queue.get()
            if (IR_queue.qsize() > 0):
                if (TA is not None and GO is not None):
                    frame_IR = IR_queue.get()

                    # [De-Noise]
                    # 1. Spatial filtering
                    frame_IR = cv.medianBlur(frame_IR.astype(np.float32), 3)
                    frame_IR = cv.blur(frame_IR.astype(np.float32), (3, 3))

                    # 2. Remove sensor's fixed-pattern noise
                    frame_IR -= FPN

                    # 3. Temporal filtering
                    TNR_LIST += [frame_IR]
                    if (len(TNR_LIST) > 1): frame_IR = np.average(TNR_LIST, axis=0)
                    if (len(TNR_LIST) > 3): TNR_LIST.pop(0)

                    # [Temperature Calculation]
                    x1 = (frame_IR.shape[1] >> 1) - 4
                    x2 = x1 + 8
                    y1 = (frame_IR.shape[0] >> 1) - 4
                    y2 = y1 + 8
                    # 1. V2T is slow, please apply to a ROI rather than the whole frame
                    centerT = self.applyV2T(frame_IR[y1:y2, x1:x2], TA, GO, XTATemp, YADValues, temp_table)
                    # 2. max of the ROI
                    centerT = np.max(centerT)
                    # 3. to Celsius temperature unit
                    centerT = self.applyT2C(centerT)
                    # 4. (optional) compensate by target emissivity
                    centerT = centerT / FACE_EMISSIVITY
                    # 5. compensate by ambient temperature
                    centerT = self.applyAmbientCompensation(centerT, self.applyT2C(TA))
                    # 6. (optional) Re-calibration for fever screening
                    centerT = self.applyApplicationCalibration(centerT, REC)
                    # 7. (optional) adjust by a user defined offset
                    centerT = centerT + OFFSET
                    print('Center Temperature:', round(centerT, 1), '℃')

                    # [Color (palette) Mapping]
                    # 1. Normalized to 0 ~ 1
                    frame_IR = (frame_IR - np.min(frame_IR)) / (np.max(frame_IR) - np.min(frame_IR))
                    # 2. Converted by a specific color mapping (as RGBA format)
                    frame_IR = plt.cm.rainbow(frame_IR)
                    # 3. Map to 8-bit range
                    frame_IR = (frame_IR * 255).astype(np.uint8)

                    # Convert to OpenCV pixel format
                    frame_IR = cv.cvtColor(frame_IR, cv.COLOR_RGBA2BGR)

                    # (optional) draw an ROI for demo
                    # cv.rectangle(frame_IR, (x1, y1), (x2, y2), (255, 255, 255), 1)

            # Display one frame
            if (frame_RGB is not None and frame_IR is not None):
                # Please resize frame_IR/frame_RGB to fit your application need
                frame_IR = cv.resize(frame_IR, (frame_RGB.shape[1], frame_RGB.shape[0]), interpolation=cv.INTER_CUBIC)
                # frame = np.concatenate([frame_RGB, frame_IR], axis=1)
                alpha=0.55
                beta=1-alpha
                gamma=0
                frame=cv.addWeighted(frame_RGB,alpha,frame_IR,beta,gamma)
                frame_result=frame
                if CSI_ready==False:
                    My_GServer=Pool(1)
                    My_GServer.starmap_async(GstServer(), [])
                    CSI_ready=True
        return
    
    def applyV2T(self,rawDataBuf, Ta, globalOffset, xtatemp, yadvalues, temptable):
        tempBuf = rawDataBuf.flatten()
        TABLE_OFFSET = 1024
        colIdx = -1
        rowIdx = -1
        for idx in range(len(xtatemp)):
            if xtatemp[idx] > Ta:
                colIdx = idx
                break

        for i in range(len(tempBuf)):
            for idx in range(len(yadvalues)):
                if (yadvalues[idx] - TABLE_OFFSET) > tempBuf[i]:
                    rowIdx = idx
                    break

            # Collect temperature region from table
            rowStart, rowEnd, colStart, colEnd = 0, 0, 0, 0
            if (rowIdx > 0):
                rowStart = rowIdx - 1
                rowEnd = rowIdx

            if (colIdx > 0):
                colStart = colIdx - 1
                colEnd = colIdx

            tempCandidates = [
                temptable[rowStart * len(xtatemp) + colStart], temptable[rowStart * len(xtatemp) + colEnd],
                temptable[rowEnd * len(xtatemp) + colStart], temptable[rowEnd * len(xtatemp) + colEnd],
            ]
            # Apply Bilinear to get estimated temperature
            if (colStart == colEnd):
                wx = 0
            else:
                wx = (Ta - xtatemp[colStart]) / (xtatemp[colEnd] - xtatemp[colStart])
            if (rowStart == rowEnd):
                wy = 0
            else:
                wy = (tempBuf[i] + TABLE_OFFSET - yadvalues[rowStart]) / (yadvalues[rowEnd] - yadvalues[rowStart])
            bilinearRow1 = tempCandidates[0] * (1 - wx) + tempCandidates[1] * (wx)
            bilinearRow2 = tempCandidates[2] * (1 - wx) + tempCandidates[3] * (wx)
            bilinearCol = bilinearRow1 * (1 - wy) + bilinearRow2 * (wy)
            tempBuf[i] = bilinearCol
            tempBuf[i] += globalOffset

        return tempBuf.reshape(rawDataBuf.shape)
    
    def applyT2C(self,x):
        # convert Kelvin to Celsius
        return x / 10 - 273.15
    
    def applyAmbientCompensation(self,x,Ta):
        return x + (0.247 * Ta - 2.773)
    
    def applyApplicationCalibration(self,x,rec):
        # Re-calibration for fever screening application
        # NOTE:
        # 1. x must be Celsius temperature
        # 2. y will be bounded to RECALIBRATION_MAX/MIN
        RECALIBRATION_MIN = 35.0
        RECALIBRATION_MAX = 40.0
        x = x + rec - 37.5
        y = 1.0 / (1.0 + math.exp(-0.5 * x))
        return y * (RECALIBRATION_MAX - RECALIBRATION_MIN) + RECALIBRATION_MIN

class SensorFactory(GstRtspServer.RTSPMediaFactory):
    def __init__(self, **properties):
        super(SensorFactory, self).__init__(**properties)
        global frame_result
        self.frame = frame_result
        self.number_frames = 0
        self.fps = 30
        self.duration = 1 / self.fps * Gst.SECOND  # duration of a frame in nanoseconds
        self.launch_string = 'appsrc name=source is-live=true block=true format=GST_FORMAT_TIME ' \
                             'caps=video/x-raw,format=BGR,width=960,height=720,framerate=20/1 ' \
                             '! videoconvert ! video/x-raw,format=I420 ' \
                             '! x264enc speed-preset=ultrafast tune=zerolatency ' \
                             '! rtph264pay config-interval=1 name=pay0 pt=96 '.format(self.fps)

    def on_need_data(self, src, lenght):
        self.frame = frame_result
        data = self.frame.tostring()
        buf = Gst.Buffer.new_allocate(None, len(data), None)
        buf.fill(0, data)
        buf.duration = self.duration
        timestamp = self.number_frames * self.duration
        buf.pts = buf.dts = int(timestamp)
        buf.offset = timestamp
        self.number_frames += 1
        retval = src.emit('push-buffer', buf)
        print('pushed buffer, frame {}, duration {} ns, durations {} s'.format(self.number_frames,
                                                                            self.duration,
                                                                            self.duration / Gst.SECOND))
        if retval != Gst.FlowReturn.OK:
            print(retval)

    def do_create_element(self, url):
        return Gst.parse_launch(self.launch_string)

    def do_configure(self, rtsp_media):
        self.number_frames = 0
        appsrc = rtsp_media.get_element().get_child_by_name('source')
        appsrc.connect('need-data', self.on_need_data)

class GstServer(GstRtspServer.RTSPServer):
    def __init__(self, **properties):
        super(GstServer, self).__init__(**properties)
        self.factory = SensorFactory()
        self.factory.set_shared(True)
        self.get_mount_points().add_factory("/test", self.factory)
        self.attach(None)
        #  start serving
        print ("stream ready at rtsp://127.0.0.1:" + "8554" + "/test")
        #  this com IP address
        print ("stream ready at rtsp://192.168.1.157:" + "8554" + "/test")

if __name__ == "__main__":
    try:
        Gst.init(None)
        CSI_Saturn_cam=CSI_Saturn()
        My_CSI=Pool(1)
        My_CSI.starmap_async(CSI_Saturn_cam.Execute(), [])
        # server = GstServer()
        loop = GLib.MainLoop()
        loop.run()
    except Exception as e:
        print(e)
        raise
